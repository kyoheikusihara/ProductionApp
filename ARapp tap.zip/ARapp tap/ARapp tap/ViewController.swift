//
//  ViewController.swift
//  ARapp tap
//
//  Created by Kyohei Kushihara on 2017/12/01.
//  Copyright © 2017年 Kyohei Kushihara. All rights reserved.
//


//名前、奥行き、幅
import UIKit
import ARKit
import SceneKit

class ViewController: UIViewController, ARSCNViewDelegate {
    var delegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var isMeasuring = false
    var startPosition: SCNVector3!
    var cylinderNode: SCNNode?
    
    lazy var sceneView: ARSCNView = {
        let view = ARSCNView(frame: CGRect.zero)
        view.delegate = self
        view.autoenablesDefaultLighting = true
        view.antialiasingMode = SCNAntialiasingMode.multisampling4X
        return view
    }()
    
    //距離と平面認識の状態を表示する
    lazy var infoLabel: UILabel = {
        let label = UILabel(frame: CGRect.zero)
        label.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.title1)
        label.textAlignment = .center
        label.backgroundColor = .white
        return label
    }()
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(sceneView)//AR画面の表示
        view.addSubview(infoLabel)//画面上部のラベルの表示
        ImageView()
        
        //家具家電カテゴリ
        let label = UILabel()
        label.frame = CGRect(x:150, y:70, width:300, height:30)
        label.font = UIFont.systemFont(ofSize: 18)
        label.text = self.delegate.categoryInfo
        self.view.addSubview(label)
        
        //戻るボタンの設定
        let backButton = UIButton()
        backButton.setTitle("戻る", for: .normal)
        backButton.setTitleColor(UIColor.white, for: .normal)
        backButton.setTitleColor(UIColor.red, for: .highlighted)
        backButton.frame = CGRect(x:0, y:0, width:90, height:50)
        backButton.tag = 2
        backButton.layer.position = CGPoint(x: 50, y:600)
        backButton.backgroundColor = UIColor(red:59/255,green:89/255,blue:152/255,alpha:0.7)
        backButton.layer.cornerRadius = 10
        backButton.layer.borderWidth = 1
        //ボタンをタップした時に実行するメソッドを指定
        backButton.addTarget(self, action: #selector(ViewController.goBack(_sender:)), for:.touchUpInside)
        
        //削除ボタンの設定
        let resetButton = UIButton()
        resetButton.setTitle("削除", for: .normal)
        resetButton.setTitleColor(UIColor.white, for: .normal)
        resetButton.setTitleColor(UIColor.red, for: .highlighted)
        resetButton.frame = CGRect(x:0, y:0, width:90, height:50)
        resetButton.tag = 3
        resetButton.layer.position = CGPoint(x: 320, y:600)
        resetButton.backgroundColor = UIColor(red:59/255,green:89/255,blue:152/255,alpha:0.7)
        resetButton.layer.cornerRadius = 10
        resetButton.layer.borderWidth = 1
        resetButton.addTarget(self, action: #selector(ViewController.resetSession), for:.touchUpInside)
        
        //測定ボタンの設定
        let measureButton = UIButton()
        measureButton.setTitle("測定開始", for: .normal)
        measureButton.setTitle("測定中", for: .highlighted)
        measureButton.setTitleColor(UIColor.white, for: .normal)
        measureButton.setTitleColor(UIColor.red, for: .highlighted)
        measureButton.frame = CGRect(x:0, y:0, width:120, height:50)
        measureButton.tag = 4
        measureButton.layer.position = CGPoint(x: self.view.frame.width/2, y:500)
        measureButton.backgroundColor = UIColor(red:59/255,green:89/255,blue:152/255,alpha:0.7)
        measureButton.layer.cornerRadius = 10
        measureButton.layer.borderWidth = 1
        measureButton.addTarget(self, action: #selector(ViewController.beginMeasure(_:)), for:.touchDown)
        measureButton.addTarget(self, action: #selector(ViewController.touchUpInside(_:)), for:.touchUpInside)
        measureButton.addTarget(self, action: #selector(ViewController.touchUpOutside(_:)), for:.touchUpOutside)
        
        //viewにボタンを追加する
        self.view.addSubview(backButton)
        self.view.addSubview(resetButton)
        self.view.addSubview(measureButton)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        sceneView.frame = view.bounds
        infoLabel.frame = CGRect(x: 0, y: 20, width: view.bounds.width, height: 80)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        //平面の検出有効化
        configuration.planeDetection = .horizontal
        sceneView.session.run(configuration)
    }
    
    //画面中央に点を設定
    private func ImageView(){
        let centerPoint:UIImage = UIImage(named:"target.png")!
        let imageView = UIImageView(image:centerPoint)
        let screenWidth:CGFloat = view.frame.size.width
        let screenHeight:CGFloat = view.frame.size.height
        imageView.center = CGPoint(x:screenWidth/2, y:screenHeight/2)
        self.view.addSubview(imageView)
    }
    
    //測定完了ボタンを押した際に呼び出す処理
    @objc func onClick(_ sender: UIButton) {// selectorで呼び出す場合Swift4からは「@objc」をつける。
        //数値のみを取り出す処理
        let widthMixedString = infoLabel.text
        let width = (widthMixedString?.components(separatedBy: NSCharacterSet.decimalDigits.inverted))
        let widthNumber = width?.joined()
        //int型からdouble型への変換
        let doubleWidth: Double = atof(widthNumber)
        let width_i = doubleWidth/10
        //家具家電の横幅の値の保持
        self.delegate.widthInfo = width_i
        let nextvc = SecondArView()
        self.present(nextvc, animated: true, completion: nil)
        //送り先のvcをインスタンス化
        let recieveViewController: SecondArView = SecondArView()
        self.navigationController?.pushViewController(recieveViewController, animated: true)
    }
    
    //戻るボタンを押した際に呼び出す処理
    @objc func goBack(_sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    //ノードの削除
    @objc func resetSession() {
        self.sceneView.scene.rootNode.enumerateChildNodes {(node, _) in
        // Nodeを削除
        node.removeFromParentNode()
        }
        imageRemove()
        infoLabel.text = "横幅を測定してください"
    }
    
    // 平面認識の状態を表示
    func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        var status = "Loading..."
        switch camera.trackingState {
        case ARCamera.TrackingState.notAvailable:
            status = "Not available"
            infoLabel.backgroundColor = .red
        case ARCamera.TrackingState.limited(_):
            status = "Analyzing..."
            infoLabel.backgroundColor = .red
        case ARCamera.TrackingState.normal:
            status = "横幅を指定してください"
            infoLabel.backgroundColor = .green
        }
        infoLabel.text = status
    }
    
   
    // 球体のノードの作成
    func createSphereNode(position: SCNVector3, color: UIColor) -> SCNNode {
        let sphere = SCNSphere(radius: 0.005)
        let material = SCNMaterial()
        material.diffuse.contents = color
        sphere.materials = [material]
        let sphereNode = SCNNode(geometry: sphere)
        sphereNode.position = position
        return sphereNode
    }
    
    // 線のノードの作成
    func createLineNode(startPosition: SCNVector3, endPosition: SCNVector3, color: UIColor) -> SCNNode {
        let indices: [Int32] = [0, 1]
        let source = SCNGeometrySource(vertices: [startPosition, endPosition])
        let element = SCNGeometryElement(indices: indices, primitiveType: .line)
        let line = SCNGeometry(sources: [source], elements: [element])
        line.firstMaterial?.lightingModel = SCNMaterial.LightingModel.blinn
        let lineNode = SCNNode(geometry: line)
        lineNode.geometry?.firstMaterial?.diffuse.contents = color
        return lineNode
    }
    
    // 円柱のノードの作成
    func createCylinderNode(startPosition: SCNVector3, endPosition: SCNVector3, radius: CGFloat , color: UIColor, transparency: CGFloat) -> SCNNode {
        let height = CGFloat(GLKVector3Distance(SCNVector3ToGLKVector3(startPosition), SCNVector3ToGLKVector3(endPosition)))
        let cylinderNode = SCNNode()
        cylinderNode.eulerAngles.x = Float(Double.pi / 2)
        
        let cylinderGeometry = SCNCylinder(radius: radius, height: height)
        cylinderGeometry.firstMaterial?.diffuse.contents = color
        let cylinder = SCNNode(geometry: cylinderGeometry)
        
        cylinder.position.y = Float(-height/2)
        cylinderNode.addChildNode(cylinder)
        
        let node = SCNNode()
        let targetNode = SCNNode()
        
        if (startPosition.z < 0.0 && endPosition.z > 0.0) {
            node.position = endPosition
            targetNode.position = startPosition
        } else {
            node.position = startPosition
            targetNode.position = endPosition
        }
        node.addChildNode(cylinderNode)
        node.constraints = [ SCNLookAtConstraint(target: targetNode) ]
        return node
    }
    
    // 測定完了ボタンの削除
    func imageRemove(){
        for v in view.subviews {
            if let v = v as? UIButton, v.tag == 1   {
                v.removeFromSuperview()
            }
        }
        //測定ボタンの設定
        let measureButton = UIButton()
        measureButton.setTitle("測定開始", for: .normal)
        measureButton.setTitle("測定中", for: .highlighted)
        measureButton.setTitleColor(UIColor.white, for: .normal)
        measureButton.setTitleColor(UIColor.red, for: .highlighted)
        measureButton.frame = CGRect(x:0, y:0, width:120, height:50)
        measureButton.tag = 4
        measureButton.layer.position = CGPoint(x: self.view.frame.width/2, y:500)
        measureButton.backgroundColor = UIColor(red:59/255,green:89/255,blue:152/255,alpha:0.7)
        measureButton.layer.cornerRadius = 10
        measureButton.layer.borderWidth = 1

        measureButton.addTarget(self, action: #selector(ViewController.beginMeasure(_:)), for:.touchDown)
        measureButton.addTarget(self, action: #selector(ViewController.touchUpInside(_:)), for:.touchUpInside)
        measureButton.addTarget(self, action: #selector(ViewController.touchUpOutside(_:)), for:.touchUpOutside)
        
        self.view.addSubview(measureButton)
    }
    
    // 計測開始
    @IBAction func beginMeasure(_ sender: Any) {
        if let position = getCenter() {
            for node in sceneView.scene.rootNode.childNodes {
                node.removeFromParentNode()
            }
            startPosition = position
            isMeasuring = true
            
            let sphereNode = createSphereNode(position: startPosition, color: UIColor.red)
            sceneView.scene.rootNode.addChildNode(sphereNode)
            
            imageRemove()
        }
    }
    
    // 計測終了
    func endMeasure() {
        if !isMeasuring {
            return
        }
        isMeasuring = false
        
        if let endPosition = getCenter() {
            
            let sphereNode = createSphereNode(position: endPosition, color: UIColor.red)
            sceneView.scene.rootNode.addChildNode(sphereNode)
            
            let centerPosition = Center(startPosition: startPosition, endPosition: endPosition)
            let centerSphereNode = createSphereNode(position: centerPosition, color: UIColor.orange)
            sceneView.scene.rootNode.addChildNode(centerSphereNode)
            
            let lineNode = createLineNode(startPosition: startPosition, endPosition: endPosition, color: UIColor.white)
            sceneView.scene.rootNode.addChildNode(lineNode)
            
            let position = SCNVector3Make(endPosition.x - startPosition.x, endPosition.y - startPosition.y, endPosition.z - startPosition.z)
            let distance = sqrt(position.x*position.x + position.y*position.y + position.z*position.z)*100
            infoLabel.text = String.init(format: "横幅：%.1f cm", arguments: [distance])
            
            //測定完了ボタンの設定
            let button = UIButton()
            button.setTitle("測定完了", for: .normal)
            button.setTitleColor(UIColor.white, for: .normal)
            button.setTitle("完了", for: .highlighted)
            button.setTitleColor(UIColor.red, for: .highlighted)
            button.frame = CGRect(x:0, y:0, width:120, height:50)
            button.tag = 1
            button.layer.position = CGPoint(x: self.view.frame.width/2, y:500)
            button.backgroundColor = UIColor(red:59/255,green:89/255,blue:152/255,alpha:0.7)
            button.layer.cornerRadius = 10
            button.layer.borderWidth = 1
            button.addTarget(self, action: #selector(ViewController.onClick(_:)), for:.touchUpInside)
            
            self.view.addSubview(button)
            
            refreshCylinderNode(endPosition: endPosition)
            for v in view.subviews {
                if let v = v as? UIButton, v.tag == 4 {
                    v.removeFromSuperview()
                }
            }
        }
    }
    
    @IBAction func touchUpInside(_ sender: Any) {
        endMeasure()
    }
    
    @IBAction func touchUpOutside(_ sender: Any) {
        endMeasure()
    }
    
    // 画面の中央を取得する
    func getCenter() -> SCNVector3? {
        let touchLocation = sceneView.center
        let hitResults = sceneView.hitTest(touchLocation, types: [.featurePoint])
        if !hitResults.isEmpty {
            if let hitTResult = hitResults.first {
                return SCNVector3(hitTResult.worldTransform.columns.3.x, hitTResult.worldTransform.columns.3.y, hitTResult.worldTransform.columns.3.z)
            }
        }
        return nil
    }
    
    // 2点間の中心座標を取得する
    func Center(startPosition: SCNVector3, endPosition: SCNVector3) -> SCNVector3 {
        let x = endPosition.x - startPosition.x
        let y = endPosition.y - startPosition.y
        let z = endPosition.z - startPosition.z
        return SCNVector3Make(endPosition.x - x/2, endPosition.y - y/2, endPosition.z - z/2)
    }
    
    // 計測中に円柱の描画を更新する
    @objc func update() {
        if isMeasuring {
            if let endPosition = getCenter() {
                
                refreshCylinderNode(endPosition: endPosition)
            }
        }
    }
    
    // 円柱の更新
    func refreshCylinderNode(endPosition: SCNVector3) {
        if let node = cylinderNode {
            node.removeFromParentNode()
        }
        cylinderNode = createCylinderNode(startPosition: startPosition, endPosition: endPosition, radius: 0.001, color: UIColor.yellow, transparency: 0.5)
        sceneView.scene.rootNode.addChildNode(cylinderNode!)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            if let planeAnchor = anchor as? ARPlaneAnchor {
                // 平面を表現するノードを追加する
                node.addChildNode(PlaneNode(anchor: planeAnchor) )
            }
        }
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            if let planeAnchor = anchor as? ARPlaneAnchor, let planeNode = node.childNodes[0] as? PlaneNode {
                // ノードの位置及び形状を修正する
                planeNode.update(anchor: planeAnchor)
            }
        }
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}
