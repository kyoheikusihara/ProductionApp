//
//  WebViewController.swift
//  ARKitMeasurementSample
//
//  Created by Kyohei Kushihara on 2017/11/10.
//  Copyright © 2017年 Classmethod.Inc. All rights reserved.
//

import UIKit

class WebView: UIViewController , UIWebViewDelegate {
    var delegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let category = self.delegate.categoryInfo!
        let depth = self.delegate.depthInfo!
        let depth_date: String = String("\(depth)")
        let width = self.delegate.widthInfo!
        let width_date: String = String("\(width)")
        
        let urlStr = "https://buybymeasure.prop-2017-team-a.ks.service.cloud.teu.ac.jp/?\(category) \(depth_date) \(width_date)"
        print (urlStr)
        // URLを指定
        let url = URL(string: urlStr.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)!)
        print(url!)
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url!, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url!)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}


