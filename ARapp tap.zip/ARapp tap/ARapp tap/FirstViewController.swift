//
//  FirstViewController.swift
//  ARapp tap
//
//  Created by Kyohei Kushihara on 2017/12/01.
//  Copyright © 2017年 Kyohei Kushihara. All rights reserved.
//

//スプラッシュ画面実装 スクロールで高さをとる
//初期画面に戻れなくする　平面認識の状態をラベルの背景色で変更する
import UIKit

class FirstViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    @IBOutlet weak var textField: UITextField!
    var delegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    var pickerView: UIPickerView = UIPickerView()
    let list = ["","本棚", "テーブル", "チェアー", "テレビ台", "ベッド", "テレビ", "冷蔵庫", "レンジ"]
    
    // 家具家電カテゴリで渡す
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        self.delegate.categoryInfo = textField.text
        //送り先のvcをインスタンス化
        let recieveViewController: ViewController = ViewController()
        self.navigationController?.pushViewController(recieveViewController, animated: true)
    }
    
        override func viewDidLoad() {
        super.viewDidLoad()
        
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.showsSelectionIndicator = true
        
        let toolbar = UIToolbar(frame: CGRectMake(0, 0, 0, 35))
        let doneItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(FirstViewController.done))
        let cancelItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(FirstViewController.cancel))
        toolbar.setItems([cancelItem, doneItem], animated: true)
        
        self.textField.inputView = pickerView
        self.textField.inputAccessoryView = toolbar
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return list.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return list[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.textField.text = list[row]
    }
    
    @objc func cancel() {
        self.textField.text = ""
        self.textField.endEditing(true)
    }
    
    @objc func done() {
        self.textField.endEditing(true)
    }
    
    func CGRectMake(_ x: CGFloat, _ y: CGFloat, _ width: CGFloat, _ height: CGFloat) -> CGRect {
        return CGRect(x: x, y: y, width: width, height: height)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
